for English users.
Please use a setup, overwriting by the contents of the EnglishSettingFilePack folder making it operate in English mode.
A setup of RCX.ini should look at the comment currently written to inside.

A fine setup should look at the explanation in RCX.ini.

Operation is carried out also in the state of the first stage.

I continue to struggle with the development of Multiple Sclerosis. 
Donations are welcome.

please edit the RCX.ini


RCX.ini

[RoChaOption]
;//----------------------------------------------------------------------------
;filename of the RO Client is specified.
;e.g.)ROClientExeName=RagexeRE.exe
;----------------------------------------------------------------------------//
ROClientExeName=

[Ragnarok]
Dir=C:\Program Files\Gravity\RagnarokOnline

[CharServers]
128.241.92.226=US_Valkyrie
    .
    .
    .

