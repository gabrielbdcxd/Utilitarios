<html>
<head>
<meta http-equiv=content-type content=text/html; charset=iso-8859-1>
<title>Documento sem t&iacute;tulo</title>
<link rel="stylesheet" href="css/style.css" />
</head>

<body>
<div id="infos">
  <div class="titulopaginas_infos"><span style="color:#fff">Doa��es</span></div>
<div class="conteudoinfo">
<font color="#FF6600"size="3">POR QUE DOAR?</font>
<li>Todos os meses temos um gasto muito alto com a manuten&ccedil;&atilde;o e funcionamento do servidor. Ent&atilde;o, com o prop&oacute;sito de colaborar com a manuten&ccedil;&atilde;o e ajudar com os gastos do servidor, aceitamos Contribui&ccedil;&otilde;es. &Eacute; importante lembrar que nenhuma taxa &eacute; cobrada para jogar em nosso servidor, e quem contribui, faz isso por livre e espont&acirc;nea vontade. 

A cada R$ 1 em Contribui&ccedil;&atilde;o voc&ecirc; recebe 100 cr&eacute;ditos dentro do jogo. Ap&oacute;s receber seus cr&eacute;ditos, basta acessar o NPC em prontera para visualiza-los e gerencia-los. Voc&ecirc; poder trocar por itens ou at&eacute; mesmo conta VIP. 

O Prazo maximo para entrega dos creditos &eacute; de at&eacute; 48 Horas ulteis, N&atilde;o conta Sabado, Domingo e Feriados.</li>

<br />
<font color="#FF6600" size="3">COMO DOAR?</font>
  <li>Para fazer uma doa&ccedil;&atilde;o e muito simples, apenas clique na imagem abaixo:</li>
  <!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/checkout/v2/donation.html" method="post">
<input type="hidden" name="receiverEmail" value="letsrobr@hotmail.com" />
<input type="hidden" name="currency" value="BRL" />
<input type="image" align="bottom" src="https://p.simg.uol.com.br/out/pagseguro/i/botoes/doacoes/164x37-doar-assina.gif" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO -->

  <li>Logo ap&oacute;s o clique na imagem vai pedir um valor, apenas indique a quantidade que voc&ecirc; ir&aacute; doar, e logo ap&oacute;s informe seu email, ap&oacute;s isso ira abrir uma pagina com varios cart&otilde;es selecione um ou selecione a op&ccedil;&atilde;o boleto, caso seja boleto apenas clique em "Gerar Boleto", se for cart&atilde;o informe os dados requeridos.</li>
  <li>Ap&eacute;nas lembrando, PAGSEGURO e um forma totalmente segura de fazer uma doa&ccedil;&atilde;o ao servidor.</li>
  <font color="#FF6600" size="3">CONFIRMA&Ccedil;&Atilde;O DE DOA&Ccedil;&Atilde;O</font>
  <li>Para confirma sua doa&ccedil;&atilde;o preencha os dados requeridos clicando na imagem.</li>
  <p align="center"><a href="http://the-rag.net/confirm/confirm.html"><img src="css/images/confirm.png" /></a></p>
  <font color="#FF6600" size="3">VANTAGENS DE DOAR</font>
  <li>S&atilde;o varias as vantagens de doar, voc&ecirc; pode adquirir, vip, itens exclusivos e utencilios entre outras coisas...
  </li>

</div>
</div>
</body>
</html>