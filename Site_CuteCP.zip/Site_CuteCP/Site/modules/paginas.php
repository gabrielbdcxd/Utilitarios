<?php
$pg = isset( $_GET['pg'] ) ? $_GET['pg'] : null;
switch ( $pg ){

	case 'download':
	include "historia.php";
	break;

	case 'info':
	include "historia.php";
	break;
	
	case 'doa':
	include "vip.php";
	break;
	
	case 'register':
	include "register.php";
	break;

	default:
	include ("home.php");
	break;
	

}
?>