﻿<?php
/*
 * Este sistema web é protegido por leis internacionais 
 * e pela lei de Deus.
 *
 * Afinal de contas, só Deus sabe como essa merda funciona..
 * -------------
 * desenvolvido por eru yuuko
 */
$version = '1.1.0';
require_once('system/nucleo.php');
require_once('system/database.php');
require_once('system/functions.php');
require_once('system/rain.tpl.class.php');
session_start();
$mysql->build_mysql();
// template system
$tpl = new RainTPL();
raintpl::$tpl_dir = "template/". THEME ."/";
// todas as variaveis e arquivos do sistema iniciados
DEFINE( 'IS_RUN', true );
// global vars
$tpl->assign( 'randomize', rand(5000000,1000000000) );
$tpl->assign( 'cp_title', CP_TITLE );
$tpl->assign( 'cp_desc', CP_DESC );
$tpl->assign( 'cute_version', $version );
$tpl->assign( 'is_logged', is_logged() );
// check login session
if( is_logged() )
{
	$tpl->assign( 'member', array( 'account_id' => s_var( 'account_id' ), 'login' => s_var( 'login' ),	'gm_level' => s_var( 'gm_level' ) ) );
	$member = array( 'account_id' => s_var( 'account_id' ), 'login' => s_var( 'login' ),	'gm_level' => s_var( 'gm_level' ) );
}
require_once( 'modules/index.php' );
?>