# CuteCP
## Painel de Controle para servidores privados de Ragnarök Online

## Funcionalidades ativas:
* Login
* Registro
* Ranking de Zeny
* Ranking de Level
* Ranking de Clã
* Ranking de Fama
* Ver Personagens
* Quem está online

## Equipe
Eru Yuuko - desenvolvedora geral

## Contribuidores
mkbu95
