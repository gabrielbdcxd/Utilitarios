<?php if(!class_exists('raintpl')){exit;}?><html>
<head>
<title>Documento sem t&iacute;tulo</title>
<link rel="stylesheet" href="template/cute/./css/style.css" />
</head>

<body>
<div id="infos">
  <div class="titulopaginas"><span style="color:#fff">Equipe</span></div>
<div class="conteudoinfo">
<font color="#FF6600"size="3">ADMINISTRADORES</font>
<li>Administrador: [ADM] Fly </li>
<li>Competências: Assuntos Gerais do Servidor.</li>
<br />
<li>Administrador: [ADM] Unknöwn </li>
<li>Competências: Assuntos Gerais do Servidor.</li>
<br>
<font color="#FF6600"size="3">GAME-MASTER</font>
<li>Game-Master:  </li>
<li>Competências: .</li>
<br />
<font color="#FF6600"size="3">COMMUNITY MASTER</font>
<li>Community Master:  </li>
<li>Competências: .</li>
<br />
</div>
</div>
</body>
</html>