<?php if(!class_exists('raintpl')){exit;}?><!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="template/cute/css/style.css?<?php echo $randomize;?>" type="text/css" rel="stylesheet" >
<link href="template/cute/css/redmond/jquery-ui-1.10.0.custom.css" rel="stylesheet">
<script src="template/cute/js/jquery-1.9.0.js"></script>
<script src="template/cute/js/jquery-ui.js"></script>
<script>
	$(function(){
		$('.button-ui').button();
	});
</script>
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/pt_BR/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<title><?php echo $cp_title;?> :: <?php echo $cute_version;?></title>
</head>
<body>

<div id="banner">    
<?php if( $is_logged ){ ?>
		<div class="whoislogged">Você está logado como: <b><?php echo $member["login"];?></b>.</div>
	<?php } ?>
</div>
<div id="content">

  <!-- sidebar -->
  <?php $tpl = new RainTPL;$tpl_dir_temp = self::$tpl_dir;$tpl->assign( $this->var );$tpl->draw( dirname("sidebar") . ( substr("sidebar",-1,1) != "/" ? "/" : "" ) . basename("sidebar") );?>
  <!-- sidebar -->
  <!-- conteudo -->
  <table width="1000" border="0" cellspacing="1" cellpadding="1">
  <tr>
    <td><div id="hall_da_fama">
<div class="titulopaginas"><span style="color:#fff">Hall da Fama</span></div>
<div class="top_hall"><br><img src="template/cute/css/images/top.png" /></div><br />
<table align="center">
<tr>
<td align="left">Nome:</td>
<td></td>
</tr>
<tr>
<td align="left">Idade:</td>
<td> </td>
</tr>
<tr>
<td align="left">Nick:</td>
<td></td>
</tr>
<tr>
<td align="left">Cl&atilde;</td>
<td></td>
</tr>
</table>
</div>
<div id="guerra_emperium">
<div class="titulopaginas"><span style="color:#fff">Guerra emperium</span></div>
</div>
    <td> 
     
    <div id="conteudo">
    
    <?php $tpl = new RainTPL;$tpl_dir_temp = self::$tpl_dir;$tpl->assign( $this->var );$tpl->draw( dirname("".$content."") . ( substr("".$content."",-1,1) != "/" ? "/" : "" ) . basename("".$content."") );?>
  </div></td>
    <td align="center"><div id="top_ragnarok">
<div class="titulopaginas"><span style="color:#fff">Vote ajude o servidor</span></div>
<div id="top_1">
<a href="http://www.topragnarok.com.br/index.php?s=vote&id=21035"><img src="template/cute/img/top/top_br.png" /></a>
<a href="http://www.topragnarok.org/votar/id5673/"><img src="template/cute/img/top/top_200.png" /></a>
<a href="http://www.topservers200.com/in.php?id=8889"><img src="template/cute/img/top/top_org.png" /></a>
</div>
</div>
<div id="plataforma_face">
<div class="titulopaginas"><span style="color:#fff">Curta nossa pagina</span></div>
<div class="fb-like-box" data-href="http://www.facebook.com/flyro2013?fref=ts" data-width="240" data-height="290" data-show-faces="true" data-stream="false" data-border-color="#FFF" data-header="false"></div>
</div>
</td>
  </tr>
</table>


  <!-- conteudo -->
</div>
<!-- creditos -->
<?php $tpl = new RainTPL;$tpl_dir_temp = self::$tpl_dir;$tpl->assign( $this->var );$tpl->draw( dirname("rodape") . ( substr("rodape",-1,1) != "/" ? "/" : "" ) . basename("rodape") );?>
<!-- creditos -->
</body>
</html>