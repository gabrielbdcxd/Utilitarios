<?php if(!class_exists('raintpl')){exit;}?><div class="titulopaginas"><span style="color:#fff">Quem está online</span></div>
<br />
<div class="conteudo">

<table width="400" cellpadding="5" cellspacing="0">
<tr>
Há <b><?php echo $online_count;?></b> jogadores online.
  <?php if( $online_count > 1 ){ ?>
  </tr>
      <tr>
      
        <td>Nome</td>
        <td align="center">Level de Classe</td>
        <td align="center">Level de Job</td>
        <td>Classe</td>
		<?php if( $is_logged ){ ?><?php if( $member["gm_level"] >= $allow_last_location ){ ?><td>Último local</td><?php } ?><?php } ?>
      </tr>
  <?php $i=$this->var['i']=0;?>
  <?php $counter1=-1; if( isset($dados) && is_array($dados) && sizeof($dados) ) foreach( $dados as $key1 => $value1 ){ $counter1++; ?>
  <tr>
    <td><?php if( $is_logged && $dados["$i"]["level"] >= 1 && $dados["$i"]["level"] <= 10 ){ ?><span class="badge badge-orange">VIP</span><?php } ?> <?php echo $dados["$i"]["name"];?></td>
    <td align="center"><?php echo $dados["$i"]["base_level"];?></td>
    <td align="center"><?php echo $dados["$i"]["job_level"];?></td>
	<td><?php echo getjobname($dados["$i"]["class"]); ?></td>
   <?php if( $is_logged ){ ?><?php if( $member["gm_level"] >= $allow_last_location ){ ?><td><?php echo $dados["$i"]["last_map"];?></td><?php } ?><?php } ?>
  </tr>
  <?php $i=$this->var['i']=$i+1;?>
  <?php } ?>
  <?php } ?>
</table>
</div>