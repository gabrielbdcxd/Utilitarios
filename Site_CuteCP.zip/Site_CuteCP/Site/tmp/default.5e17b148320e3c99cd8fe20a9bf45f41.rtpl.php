<?php if(!class_exists('raintpl')){exit;}?><div class="titulopaginas"><span style="color:#fff">Pagina Princial</span></div>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv=content-type content=text/html; charset=iso-8859-1>
<title>Documento sem t&iacute;tulo</title>
</head>
<script type="text/javascript" src="template/cute/./js/jquery-1.6.1.min.js" ></script>
<script type="text/javascript" src="template/cute/./js/jquery.cycle.all.min.js" ></script>  
<script type="text/javascript">
   $(function(){
         $("#slide ul").cycle({
            fx: 'fade',
            speed: 2500,
            timeout: 5000,
         })      
	$('#eventos').hide();	
	$('.noticias a').click(function(){
		$('#noticias').show();
		$('#eventos').hide();
	});
	
	$('.eventos a').click(function(){
		$('#eventos').show();
		$('#noticias').hide();
	});
	
});

      
</script>
<body>

 <div id="slide">
               		 <ul id="rotate">
    					<img src="template/cute/./img/01.png" />
       					<img src="template/cute/./img/02.png" />
        				<img src="template/cute/./img/03.png" />
        				
       
        			</ul>
	  </div>
<div class="titulopaginas"><span style="color:#fff">Todas as noticias</span></div>
<span style="overflow:hidden;"><iframe width="430" height="400" src="http://fly-ro.com/noticias/noticias.php" frameborder="0" allowfullscreen></iframe></span>
</div>
</body>
</html>