<?php if(!class_exists('raintpl')){exit;}?><div class="title">Criar nova conta</div>
<div class="conteudo">
<?php if( isset( $msg ) ){ ?>
	<?php echo $msg;?>
<?php } ?>
    <center>
        <form name="logar" method="post" action="">
            <table width="100%" border="0" cellpadding="4" cellspacing="0" class="table-simple">
              <tr>
                <td>Login:</td>
                <td align="center"><input type="text" name="login" id="textfield" /></td>
              </tr>
              <tr>
                <td>Senha:</td>
                <td align="center"><input type="password" name="senha" id="textfield" /></td>
              </tr>
              <tr>
                <td>Confirme a senha:</td>
                <td align="center"><input type="password" name="confirme_senha" id="textfield" /></td>
              </tr>
              <tr>
                <td>Email:</td>
                <td align="center"><input type="text" name="email" id="textfield" /></td>
              </tr>
              <tr>
                <td>Data de Nascimento</td>
                <td align="center">
                <table width="100" border="0">
                  <tr>
                    <td>Dia:</td>
                    <td>Mês:</td>
                    <td>Ano:</td>
                  </tr>
                  <tr>
                    <td><select name="dia" id="select">
                    <?php $counter1=-1; if( isset($dias) && is_array($dias) && sizeof($dias) ) foreach( $dias as $key1 => $value1 ){ $counter1++; ?><option value="<?php echo $key1;?>"><?php echo $value1;?></option>
                    <?php } ?>
                  </select></td>
                    <td><select name="mes" id="select">
                    <?php $counter1=-1; if( isset($meses) && is_array($meses) && sizeof($meses) ) foreach( $meses as $key1 => $value1 ){ $counter1++; ?><option value="<?php echo $key1+1;?>"><?php echo $value1;?></option>
                    <?php } ?>
                  </select></td>
                    <td><select name="ano" id="select">
                    <?php $counter1=-1; if( isset($ano) && is_array($ano) && sizeof($ano) ) foreach( $ano as $key1 => $value1 ){ $counter1++; ?><option value="<?php echo $value1;?>"><?php echo $value1;?></option>
                    <?php } ?>
                  </select></td>
                  </tr>
                </table>
				</td>
              </tr>
			  <tr>
                <td>Sexo:</td>
                <td align="center"><select name="sexo" id="select">
                    <option value="M">Masculino</option>
					<option value="F">Feminino</option>
                  </select></td>
              </tr>
              <tr>
                <td>&nbsp;</td>
                <td align="center"><button type="submit" class="cupid-green">Criar uma nova conta</button></td>
              </tr>
            </table>
      </form>
  </center>
</div>