<?php if(!class_exists('raintpl')){exit;}?><div class="titulopaginas"><span style="color:#fff">Meus Personagens</span></div>

<div class="conteudo">
  <table width="99%" cellpadding="5" cellspacing="0" class="tabela">
  <thead class="thead">
      <tr>
	    <td align="center">Slot</td>
        <td align="center">Nome</td>
        <td align="center">Classe</td>
        <td align="center">N&iacute;vel</td>
		<td align="center">Zeny</td>
        <td align="center">&Uacute;ltimo Mapa</td>
      </tr>
  </thead>
  <?php $i=$this->var['i']=0;?>
  <?php $counter1=-1; if( isset($dados) && is_array($dados) && sizeof($dados) ) foreach( $dados as $key1 => $value1 ){ $counter1++; ?>
  <tr>
    <td align="center"><?php echo $dados["$i"]["char_num"];?></td>
    <td align="center"><?php echo $dados["$i"]["name"];?></td>
	<td align="center"><?php echo getjobname($dados["$i"]["class"]); ?></td>
	<td align="center"><?php echo $dados["$i"]["base_level"];?> / <?php echo $dados["$i"]["job_level"];?></td>
	<td align="center"><?php echo $dados["$i"]["zeny"];?></td>
    <td align="center"><?php echo $dados["$i"]["last_map"];?></td>
  </tr>
  <?php $i=$this->var['i']=$i+1;?>
  <?php } ?>
</table>
</div>