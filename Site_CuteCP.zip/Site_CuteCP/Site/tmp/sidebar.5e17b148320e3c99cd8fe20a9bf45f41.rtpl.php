<?php if(!class_exists('raintpl')){exit;}?>
<div id="menu">
<table width="800" border="0" cellspacing="0" cellpadding="0" style="margin-left:190px; margin-top:5px;">
	      <tr align="center">
 
	        <td width="100"><span><a href="?module=home">Home</a></span></td>
	        <td width="135"><a href="?module=infos">Informa&ccedil;&otilde;es</a></td>
	        <td width="154"><a href="?module=downloads">Downloads</a></td>
	        <td width="130"><a href="?module=doacao">Doa&ccedil;&otilde;es</a></td>
	        <td width="130"><a href="?module=equipe">Equipe</a></td>
	        <td width="110"><span style="background:none;"><a href="http://fly-ro.com/forum">F&oacute;rum</a></td>
          </tr>
	      <tr align="center" class="submenu">

	        <td>Pagina inicial</td>
	        <td>Infos do Servidor</td>
	        <td>Baixe nosso patcher</td>
	        <td>Fa&ccedil;a sua doa&ccedil;&atilde;o</td>
	        <td>Veja nossa equipe</td>
	        <td>Entre no f&oacute;rum</td>
          </tr>
  </table>


</div>
    

<div id="sidebar">

  	<ul>
        <?php if( !$is_logged ){ ?>
        <li style="margin-left:30px;" ><a href="?module=login">Efetuar login</a></li>
        <li><a href="?module=register">Criar nova conta</a></li>
        <li><a href="http://fly-ro.com/vote/login.php">Vote por Pontos</a></li>

		<?php } ?>
    </ul>
        <?php if( $is_logged ){ ?>
    <ul>
        <li><a href="?module=ranking-level">Ranking de Level</a></li>
        <li><a href="?module=ranking-zeny">Ranking de Zeny</a></li>
        <li><a href="?module=ranking-clan">Ranking de Guild</a></li>
    </ul>

    <ul>

        <li><a href="?module=statistic">Ver estatísticas</a></li>
		<li><a href="?module=characters">Ver personagens</a></li>
        <li><a href="?module=editar">Editar dados</a></li>
		<li><a href="?module=logout">Logout</a></li>
    </ul>
    <?php } ?>
</div>