<?php if(!class_exists('raintpl')){exit;}?><div class="titulopaginas"><span style="color:#fff">Ranking de Clã</span></div>

<div class="conteudo">
  <table width="440" cellpadding="0" cellspacing="0" class="tabela">
  <thead class="thead">
      <tr>
        <td align="center">Posição</td>
        <td align="center">Nome</td>
        <td align="center">Nivel</td>
        <td align="center">Experiência</td>
      </tr>
  </thead>
  <?php $i=$this->var['i']=0;?>
  <?php $pos=$this->var['pos']=1;?>
  <?php $counter1=-1; if( isset($dados) && is_array($dados) && sizeof($dados) ) foreach( $dados as $key1 => $value1 ){ $counter1++; ?>
  <tr>
    <td align="center"><?php echo $pos;?></td>
    <td align="center"><?php echo $dados["$i"]["name"];?></td>
    <td align="center"><?php echo $dados["$i"]["guild_lv"];?></td>
	<td align="center"><?php echo number_format($dados["$i"]["exp"]); ?></td>
  </tr>
  <?php $pos=$this->var['pos']=$pos+1;?>
  <?php $i=$this->var['i']=$i+1;?>
  <?php } ?>
</table>
</div>