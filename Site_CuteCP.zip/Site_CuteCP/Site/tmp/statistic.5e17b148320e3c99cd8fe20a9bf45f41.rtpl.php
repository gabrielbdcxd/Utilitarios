<?php if(!class_exists('raintpl')){exit;}?><div class="titulopaginas"><span style="color:#fff">Estatísticas</span></div>
<div class="conteudo">
    <table width="99%" border="0" cellspacing="0" class="table-simple">
      <tr>
        <td width="63%">Total de Personagens:</td>
        <td width="37%" align="center"><strong><?php echo $total_chars;?></strong></td>
      </tr>
      <tr>
        <td>Quantas vezes já logou:</td>
        <td align="center"><strong><?php echo $data["logincount"];?></strong></td>
      </tr>
      <tr>
        <td>Último IP logado no servidor:</td>
        <td align="center"><strong><?php echo $data["last_ip"];?></strong></td>
      </tr>
      <tr>
        <td>Data do último login:</td>
        <td align="center"><strong><?php echo $data["lastlogin"];?></strong></td>
      </tr>
    </table>
</div>