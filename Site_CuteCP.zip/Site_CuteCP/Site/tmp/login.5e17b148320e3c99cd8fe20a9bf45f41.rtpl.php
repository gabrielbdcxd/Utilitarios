<?php if(!class_exists('raintpl')){exit;}?><div class="titulopaginas"><span style="color:#fff">Logar em minha conta</span></div>
<div class="conteudo">
<?php if( isset( $msg ) ){ ?>
	<?php echo $msg;?>
<?php } ?>
    <center>
        <form name="logar" method="post" action="">
            <table width="249" border="0" cellpadding="4" cellspacing="4">
              <tr>
                <td>Login:</td>
                <td align="center"><input type="text" name="login" id="textfield" /></td>
              </tr>
              <tr>
                <td>Senha:</td>
                <td align="center"><input type="password" name="senha" id="textfield" /></td>
              </tr>
              <tr>
                <td>&nbsp;</td>
                <td align="center"><button type="submit" class="cupid-green">Logar</button></td>
              </tr>
            </table>
      </form>
  </center>
</div>