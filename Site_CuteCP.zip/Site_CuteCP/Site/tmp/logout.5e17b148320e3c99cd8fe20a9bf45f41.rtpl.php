<?php if(!class_exists('raintpl')){exit;}?><META HTTP-EQUIV="Refresh" CONTENT="3; URL=index.php">
<div class="title">Mensagem</div>
<div class="conteudo">Deslogado com sucesso!</div>