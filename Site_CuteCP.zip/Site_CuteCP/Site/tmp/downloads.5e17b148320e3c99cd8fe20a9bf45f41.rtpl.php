<?php if(!class_exists('raintpl')){exit;}?><html>
<head>
<title>Documento sem t&iacute;tulo</title>
<link rel="stylesheet" href="template/cute/./css/style.css" />
</head>

<body>
<div id="infos">
  <div class="titulopaginas"><span style="color:#fff">Downloads</span></div>
<div class="conteudoinfo">
<font color="#FF6600" size="3">BAIXE NOSSO PATCHER</font>

<li>Nome: Install Fly RO</li>
  <li>Exten&ccedil;&atilde;o: .exe</li>
  <li>Tamanho: 41MB</li>
 <p align="center"><a href="http://the-rag.net/down/Install%20The-Rag.exe"><img src="template/cute/./css/images/patcher.png" /></a></p>

<br />
<font color="#FF6600" size="3">BAIXE O BRO</font>
  <li>Nome do Arquivo: Cliente BRO</li>
  <li>Tamanho: 1,5gb</li>
 <p align="center"><a href="http://levelupgames.uol.com.br/ragnarok/downloads/comece-jogar/instrucoes.lhtml"><img src="template/cute/./css/images/patcher_bro.png" /></a></p>
  <br />
<font color="#FF6600" size="3">OBSERVA&Ccedil;&Atilde;O</font>
<li><font color="#FF0000">Ap&oacute;s o download, para entrar no servidor basta executar os arquivos, "intenalGuard.exe" ou o "AutoPatcher.exe", qual quer tentativa com outro aplicativo sera inviavel.</font></li>
  <li>Ap&oacute;s fazer o download do Patch Fly RO, execute-o e instale em uma pasta isolada. Em seguida copie seu Sakray, kRO (sdata.grf) ou bRO (data.grf) para a pasta criada pelo instalador. Esta pasta geralmente &eacute; encontrada em C:/The-Rag. Depois de realizar todo este processo basta registrar sua conta para jogar.
</li>

</div>
</div>
</body>
</html>