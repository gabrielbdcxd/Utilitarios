<?php if(!class_exists('raintpl')){exit;}?><html>
<head>
<title>Documento sem t&iacute;tulo</title>
<link rel="stylesheet" href="template/cute/./css/style.css" />
</head>

<body>
<div id="infos">
  <div class="titulopaginas"><span style="color:#fff">Informa&ccedil;&otilde;es</span></div>
<div class="conteudoinfo">
<font color="#FF6600"size="3">INFORMAÇÕES GERAIS</font>
<li>Rates: 1000x1000x500x</li>
  <li>N&iacute;vel m&aacute;ximo: 99/70</li>
  <li>Atributos m&aacute;x.: 99</li>
  <li>ASPD m&aacute;xima: 190</li>
  <li>Drops equipamentos gerais: 60%</li>
  <li>Drops equipamentos de MVP: 40%</li>
  <li>Drops de Cartas: Retiradas</li>
<br />
<font color="#FF6600" size="3">COMANDOS NORMAIS</font>
  <li>@go ( teleporta para cidades )</li>
  <li>@warp ( teleporta para mapas )</li>
   <li>Entre outros....</li>
  <br />
<font color="#FF6600" size="3">COMANDOS VIP</font>
  <li>@mobalive ( Mostra a posição se um monstro esta vivo. )</li>
  <li>@alootid ( Permite o drop de um determinado item )</li>
  <li>@changegm ( Permite passar a liderança de seu clã para outro membro. )</li>
  <li>@pettalk ( Permite o uso do sistema de falas dos pets. )</li>
  <li>@homtalk ( Permite o uso do sistema de falas dos homunculus. )</li>
  <li>@storeall ( Coloca todos os seus itens no armazém. )</li>
    <li>Entre outros....</li>

  <p><br />
  </p>
  <p>&nbsp;</p>
</div>
</div>
</body>
</html>