<?php 
include_once "config.php"; 
include "antisql.php";

	mysql_connect($CONFIG['server'], $CONFIG['user'], $CONFIG['senha']);
	mysql_select_db($CONFIG['dbsite']);
	$id = $_GET['id'];
	$sql = mysql_query("SELECT * FROM ".$CONFIG['dbsite'].".noticias where id='$id' limit 1");
	$exibir = mysql_fetch_array($sql);

?>
<link href="estilos/style.css" rel="stylesheet" type="text/css" />

<table width="100%" border="0" align="center" cellpadding="5" cellspacing="2">
  <tr>
    <td width="554" bgcolor="#F3F9FC" class="titulostabela" ><?php echo $exibir[1]; ?><br /></td>
  </tr>
  <tr>
    <td width="554" bgcolor="#F3F9FC" class="textos" ><?php echo $exibir[2]; ?><br />
    <div align="right">Att, <strong>Administrador. </strong> data: <strong><?php echo $exibir[3]; ?></strong></div></td>
  </tr>
  <tr>
    <td width="554" align="center" bgcolor="#F3F9FC" class="hallfama"><div align="center"><a href="javascript:window.close();">Fechar</a></div></td>
  </tr>
</table>
<p>&nbsp;</p>
