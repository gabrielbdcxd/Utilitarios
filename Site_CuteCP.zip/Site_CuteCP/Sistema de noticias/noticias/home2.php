<?php 
include_once 'config.php';
	$dbsite = mysql_connect($CONFIG['server'], $CONFIG['user'], $CONFIG['senha']);
				mysql_select_db($CONFIG['dbsite']);
				
		$noticia = mysql_query("SELECT * FROM ".$CONFIG['dbsite'].".noticias order by id desc limit 5");
		$evento = mysql_query("SELECT * FROM ".$CONFIG['dbsite'].".eventos order by id desc limit 5");		
				
?>
<script src="Scripts/AC_RunActiveContent.js" type="text/javascript"></script>
<style type="text/css">
<!--
.a {
	text-align: right;
}
-->
</style>

<div align="left">
  <?php 
    while ($exibir = mysql_fetch_array($evento)){
      echo "<table width=\"428\" border=\"0\" cellspacing=\"1\" cellpadding=\"3\">
        <tr>
          <td width=\"18%\" bgcolor=\"#B4D6EF\"><div align=\"center\" class=\"data\">".$exibir[3]."</div></td>
          <td width=\"82%\" =\"#FFFFFF\"> <span class=\"titulonoti\"><a href=\"javascript:abrir('evento.php?id=".$exibir[0]."','600','400');\">".$exibir[1]."</a></span></td>
        </tr>
      </table>";
    }
      ?>
</div>
<p align="center">&nbsp;</p>
<br />
<br />
