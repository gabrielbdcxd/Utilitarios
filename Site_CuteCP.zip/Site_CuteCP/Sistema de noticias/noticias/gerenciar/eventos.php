<?php 
include "../config.php";
session_start();
			if(!isset($_SESSION['usuadminro']) && !isset($_SESSION['senhaadminro'])){
				echo "<script>alert(\"Acesso Negado!\")</script>";
				exit;
			}
			
			
			mysql_connect($CONFIG['server'], $CONFIG['user'], $CONFIG['senha']);
	    mysql_select_db($CONFIG['dbsite']);
		
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"/>
<title><?php echo $CONFIG['titulo']; ?></title>
<link href="../estilos/style.css" rel="stylesheet" type="text/css" />
<script>
function abrir(pagina,largura,altura) {

//pega a resolu��o do visitante
w = screen.width;
h = screen.height;

//divide a resolu��o por 2, obtendo o centro do monitor
meio_w = w/2;
meio_h = h/2;

//diminui o valor da metade da resolu��o pelo tamanho da janela, fazendo com q ela fique centralizada
altura2 = altura/2;
largura2 = largura/2;
meio1 = meio_h-altura2;
meio2 = meio_w-largura2;

//abre a nova janela, j� com a sua devida posi��o
window.open(pagina,'','height=' + altura + ', width=' + largura + ', top='+meio1+', left='+meio2+'');
}
function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}
</script>
</head>
<body>
<p>&nbsp;</p>
<div align="center" class="filds">
  <table width="668" border="0" align="center" cellpadding="2" cellspacing="2">
    <tr>
      <td colspan="3"><div align="center">
        <p><strong>Eventos</strong></p>
        <p><strong><a href="javascript:abrir('novoevent.php','600','400');">Novo Evento!</a><br />
        </strong></p>
      </div></td>
    </tr>
    <tr>
      <td width="411"><strong>Eventos no momento:</strong></td>
      <td width="64">&nbsp;</td>
      <td width="177"><strong>Selecione uma a&ccedil;&atilde;o:</strong></td>
    </tr>

    
    
    <?php
	
include_once "../config.php";
	mysql_connect($CONFIG['server'], $CONFIG['user'], $CONFIG['senha']);
	mysql_select_db($CONFIG['dbsite']);
	$id = $_GET['id'];
	$sql = mysql_query("SELECT * FROM ".$CONFIG['dbsite'].".eventos order by id DESC");
	while ($exibir = mysql_fetch_array($sql)){
    
    echo  "    <tr>
	<td colspan=\"2\" bgcolor=\"#EEF1FB\"><div align=\"left\"> - ".$exibir[1]."</div></td>
      <td bgcolor=\"#EEF1FB\"><form name=\"form\" id=\"form\">
        <div align=\"center\">
          <select name=\"jumpMenu\" class=\"filds\" id=\"jumpMenu\" onchange=\"MM_jumpMenu('parent',this,0)\">
            <option>Selecione...</option>
            <option value=\"editarevent.php?&amp;id=".$exibir[0]."\">Editar</option>
            <option value=\"?acao=excluir&amp;id=".$exibir[0]."\">Excluir</option>
          </select>
        </div>
      </form></td>
	      </tr>";
	  }
      ?>
      
      
      
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
  </table>
  <form name="form" id="form">
    <a href="javascript:window.history.back(-1)">Voltar</a>
  </form>
  <form name="form2" id="form2">

  </form>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>
</p>
  <p>&nbsp;</p>
</div>
</body>
</html>

<?php 
		$acao = $_GET['acao'];
		if($acao == "excluir"){
		$id = $_GET['id'];
		$deletar = mysql_query("DELETE FROM `eventos` WHERE `eventos`.`id` = '$id' LIMIT 1");
		echo "<script>alert(\"Evento deletado com sucesso!\")</script>";
		echo "<script>window.history.back(-1)</script>";
		}


?>