<?
$dia = date('d');
$mes = date('m');
$ano = date('Y');

switch ($mes){

case 1: $mes = "01"; break;
case 2: $mes = "02"; break;
case 3: $mes = "03"; break;
case 4: $mes = "04"; break;
case 5: $mes = "05"; break;
case 6: $mes = "06"; break;
case 7: $mes = "07"; break;
case 8: $mes = "08"; break;
case 9: $mes = "09"; break;
case 10: $mes = "10"; break;
case 11: $mes = "11"; break;
case 12: $mes = "12"; break;

}

?>