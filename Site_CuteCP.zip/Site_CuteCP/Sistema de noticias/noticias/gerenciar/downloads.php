<?php 
include "../config.php";
include "data.php";
session_start();
			if(!isset($_SESSION['usuadminro']) && !isset($_SESSION['senhaadminro'])){
				echo "<script>alert(\"Acesso Negado!\")</script>";
				exit;
			}
			
			
	    mysql_connect($CONFIG['server'], $CONFIG['user'], $CONFIG['senha']);
	    mysql_select_db($CONFIG['dbsite']);
		$sql = mysql_query("SELECT * FROM ".$CONFIG['dbsite'].".download order by id DESC");
	$cont = mysql_num_rows($sql);
	$exibir = mysql_fetch_array($sql);
		
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"/>
<title><?php echo $CONFIG['titulo']; ?></title>
<link href="../estilos/style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">
<!--
function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}
//-->
</script>
<style type="text/css">
<!--
body {
	background-color: #F3F3F3;
}
-->
</style></head>
<body>
<div align="center" class="textos">
  <form name="dsad" method="post" action="">
  <table width="583" border="0" align="center" cellpadding="4" cellspacing="2">
    <tr>
      <td colspan="2"><div align="center" class="titulostabela">
        <p>Download Patch <?php echo $CONFIG['nome']; ?></p>
      </div></td>
    </tr>
    
    <tr>
      <td width="116" bgcolor="#EBF0FA"><div align="right">Vers&atilde;o:</div></td>
      <td width="445" bgcolor="#EBF0FA"><input name="vpat" type="text" class="filds" id="vpat" value="<?php echo $exibir[1]; ?>" size="5" /></td>
    </tr>
    <tr>
      <td bgcolor="#EBF0FA"><div align="right">Link para download:</div></td>
      <td bgcolor="#EBF0FA"><label>
        <input name="lpat" type="text" id="lpat" value="<?php echo $exibir[3]; ?>" size="70" />
      </label></td>
    </tr>
    <tr>
      <td bgcolor="#EBF0FA"><div align="right">Tamanho:</div></td>
      <td bgcolor="#EBF0FA"><label>
        <input name="tpat" type="text" class="filds" id="tpat" value="<?php echo $exibir[2];?>" size="9" />
      </label></td>
    </tr>
  </table>
  <table width="583" border="0" align="center" cellpadding="4" cellspacing="2">
    <tr>
      <td colspan="2"><div align="center" class="titulostabela">
          <p>Download do client Ragnarok Online</p>
      </div></td>
    </tr>
    <tr>
      <td width="116" bgcolor="#EBF0FA"><div align="right">Epis&oacute;dio:</div></td>
      <td bgcolor="#EBF0FA"><input name="vbro" type="text" class="filds" id="vbro" value="<?php echo $exibir[4]; ?>" size="20" /></td>
    </tr>
    <tr>
      <td bgcolor="#EBF0FA"><div align="right">Link para download:</div></td>
      <td bgcolor="#EBF0FA"><label>
        <input name="lbro" type="text" id="lbro" value="<?php echo $exibir[6]; ?>" size="70" />
      </label></td>
    </tr>
    <tr>
      <td bgcolor="#EBF0FA"><div align="right">Tamanho:</div></td>
      <td bgcolor="#EBF0FA"><label>
        <input name="tbro" type="text" class="filds" id="tbro" value="<?php echo $exibir[5];?>" size="9" />
      </label></td>
    </tr>
    <tr>
      <td bgcolor="#EBF0FA"><div align="right"></div></td>
      <td width="445" bgcolor="#EBF0FA"><label>
        <input name="enviar" type="submit" class="filds" id="enviar" value="Enviar" />
      </label></td>
    </tr>
  </table>
  <p>&nbsp;</p>
  </form>
  <p><a href="javascript:window.history.back(-1)">Voltar</a>&nbsp;</p>
  <p>&nbsp;</p>
  <p></p>
  <p>&nbsp;</p>
</div>
</body>
</html>

<?php 
		$enviar = $_POST['enviar'];
		
		if(isset($enviar)){
		$vpat = $_POST['vpat'];
		$lpat = $_POST['lpat'];
		$tpat = $_POST['tpat'];
				$vbro = $_POST['vbro'];
		$lbro = $_POST['lbro'];
		$tbro = $_POST['tbro'];
		
		
		$inserir = mysql_query("insert into download (versao_pat, tamanho_pat, link_pat, episodio_bro, tamanho_bro, link_bro) values ('$vpat', '$tpat', '$lpat', '$vbro', '$tbro', '$lbro')");
		if($inserir != null){
		echo "<script>alert(\"Download enviado com sucesso!\")</script>";
		echo "<script>window.history.back(-1)</script>";
		}else{
		echo "<script>alert(\"Erro: Ocorreu um erro!\")</script>";
		
		}
		}



?>
