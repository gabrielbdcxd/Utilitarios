<?php 
include "../config.php";
include "../antisql.php";
session_start();
			if(!isset($_SESSION['usuadminro']) && !isset($_SESSION['senhaadminro'])){
				echo "<script>alert(\"Acesso Negado!\")</script>";
				exit;
			}
			
			
			mysql_connect($CONFIG['server'], $CONFIG['user'], $CONFIG['senha']);
	    mysql_select_db($CONFIG['dbsite']);
		
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"/>
<title><?php echo $CONFIG['titulo']; ?></title>
<link href="../estilos/style.css" rel="stylesheet" type="text/css" />
<script>
function abrir(pagina,largura,altura) {

//pega a resolu��o do visitante
w = screen.width;
h = screen.height;

//divide a resolu��o por 2, obtendo o centro do monitor
meio_w = w/2;
meio_h = h/2;

//diminui o valor da metade da resolu��o pelo tamanho da janela, fazendo com q ela fique centralizada
altura2 = altura/2;
largura2 = largura/2;
meio1 = meio_h-altura2;
meio2 = meio_w-largura2;

//abre a nova janela, j� com a sua devida posi��o
window.open(pagina,'','height=' + altura + ', width=' + largura + ', top='+meio1+', left='+meio2+'');
}
</script>
<script type="text/javascript">
<!--
function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}
//-->
</script>
</head>
<body>
<p align="center"><span class="textos"><strong><?php echo $CONFIG['nome']; ?></strong><br />
Administra&ccedil;&atilde;o do site</span></p>
<p align="center" class="filds">Bem vindo(a)  <strong><?php echo $_SESSION['usuadminro']; ?></strong>!</p>
<div align="center" class="filds">
  <table width="524" border="0" align="center" cellpadding="0" cellspacing="0">
    <tr>
      <td colspan="3"><div align="center">
        <p><strong><br />
  Selecione uma a&ccedil;&atilde;o:</strong></p>
        </div></td>
    </tr>
    <tr>
      <td width="231">&nbsp;</td>
      <td width="26">&nbsp;</td>
      <td width="267">&nbsp;</td>
    </tr>
    <tr>
      <td><div align="right">Administrar </div></td>
      <td>&nbsp;</td>
      <td><form name="form" id="form">
        <select name="jumpMenu" class="filds" id="jumpMenu" onchange="MM_jumpMenu('parent',this,0)">
          <option>selecione...</option>
          <option value="noticias.php">Not&iacute;cias</option>
          <option value="eventos.php">Eventos</option>
          <?php 
		  if($nivel == 2){
          echo "<option value=\"pags.php\">P&aacute;ginas do site (textos)</option>";
        }
		?>
		</select>
      </form></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
  </table>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>
</p>
  <p>&nbsp;</p>
</div>
</body>
</html>