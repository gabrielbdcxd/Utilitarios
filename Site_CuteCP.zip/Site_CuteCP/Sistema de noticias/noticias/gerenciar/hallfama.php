<?php 
include "../config.php";
include "data.php";
session_start();
			if(!isset($_SESSION['usuadminro']) && !isset($_SESSION['senhaadminro'])){
				echo "<script>alert(\"Acesso Negado!\")</script>";
				exit;
			}
			
			
	    mysql_connect($CONFIG['server'], $CONFIG['user'], $CONFIG['senha']);
	    mysql_select_db($CONFIG['dbsite']);
		
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"/>
<title><?php echo $CONFIG['titulo']; ?></title>
<link href="../estilos/style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">
<!--
function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}
//-->
</script>
<style type="text/css">
<!--
body {
	background-color: #F3F3F3;
}
-->
</style></head>
<body>
<div align="center" class="textos">
  <form name="dsad" method="post" action="">
  <table width="583" border="0" align="center" cellpadding="4" cellspacing="2">
    <tr>
      <td colspan="2"><div align="center" class="titulostabela">
        <p>Hall da Fama <?php echo $CONFIG['nome']; ?></p>
      </div></td>
    </tr>
    
    <tr>
      <td width="116" bgcolor="#EBF0FA"><div align="right">Nome :</div></td>
      <td width="445" bgcolor="#EBF0FA"><input name="nome" type="text" class="filds" id="nome" size="20" /></td>
    </tr>
    <tr>
      <td bgcolor="#EBF0FA"><div align="right">Nick :</div></td>
      <td bgcolor="#EBF0FA"><label>
        <input name="nick" type="text" class="filds" id="nick" size="20" />
      </label></td>
    </tr>
    <tr>
      <td bgcolor="#EBF0FA"><div align="right">Classe preferida :</div></td>
      <td bgcolor="#EBF0FA"><input name="classe" type="text" class="filds" id="classe" size="20" /></td>
    </tr>
    <tr>
      <td bgcolor="#EBF0FA"><div align="right">cl&atilde;:</div></td>
      <td bgcolor="#EBF0FA"><input name="cla" type="text" class="filds" id="cla" size="20" /></td>
    </tr>
    <tr>
      <td bgcolor="#EBF0FA"><div align="right">Idade:</div></td>
      <td bgcolor="#EBF0FA"><input name="idade" type="text" class="filds" id="idade" size="20" /></td>
    </tr>
    <tr>
      <td bgcolor="#EBF0FA"><div align="right">Mora:</div></td>
      <td bgcolor="#EBF0FA"><input name="mora" type="text" class="filds" id="mora" size="20" /></td>
    </tr>
    <tr>
      <td bgcolor="#EBF0FA">Foto:</td>
      <td bgcolor="#EBF0FA"><label>
        <input name="foto" type="text" class="filds" id="foto" size="20" />
      (nome da foto na pasta &quot; images/fama/ &quot;)<br />
      coloque s&oacute; o nome da foto sem a exten&ccedil;&atilde;o (.gif .png etc) o formato padr&atilde;o que vai aparecer no site &eacute; <strong>.gif ent&atilde;o salve a imagem da pessoa em formato .gif</strong></label></td>
    </tr>
  </table>
  <p>
    <label>
    <input name="enviar" type="submit" class="filds" id="enviar" value="Enviar" />
    </label>
  </p>
  </form>
  <p><a href="javascript:window.history.back(-1)">Voltar</a>&nbsp;</p>
  <p>&nbsp;</p>
  <p></p>
  <p>&nbsp;</p>
</div>
</body>
</html>

<?php 
		$enviar = $_POST['enviar'];
		
		if(isset($enviar)){
		$nome = $_POST['nome'];
		$nick = $_POST['nick'];
		$classe = $_POST['classe'];
		$cla = $_POST['cla'];
		$idade = $_POST['idade'];
		$mora = $_POST['mora'];
		$foto = $_POST['foto'];
		
						
		$inserir = mysql_query("insert into fama (foto, nome, nick, classe, cla, idade, mora) values ('$foto','$nome', '$nick', '$classe', '$cla', '$idade', '$mora')");
		if($inserir != null){
		echo "<script>alert(\"Famoso enviado com sucesso!\")</script>";
		}else{
		echo "<script>alert(\"Erro: Ocorreu um erro!\")</script>";
		
		}
		}



?>
