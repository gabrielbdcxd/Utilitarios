<?php 
include "../config.php";
include "data.php";
session_start();
			if(!isset($_SESSION['usuadminro']) && !isset($_SESSION['senhaadminro'])){
				echo "<script>alert(\"Acesso Negado!\")</script>";
				exit;
			}
			
		
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"/>
<title><?php echo $CONFIG['titulo']; ?></title>
<link href="../estilos/style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">
<!--
function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}
//-->
</script>
<style type="text/css">
<!--
body {
	background-color: #F3F3F3;
}
-->
</style></head>
<body>
<div align="center" class="textos">
  <table width="583" border="0" align="center" cellpadding="4" cellspacing="2">
    <tr>
      <td colspan="2"><div align="center" class="titulostabela">
        <p>Excluir regras  <?php echo $CONFIG['nome']; ?></p>
      </div></td>
    </tr>
    
    <tr>
      <td width="455" bgcolor="#EBF0FA"><?php
      
      mysql_connect($CONFIG['server'], $CONFIG['user'], $CONFIG['senha']);
	    mysql_select_db($CONFIG['dbsite']);
		$sql = mysql_query("SELECT * FROM ".$CONFIG['dbsite'].".regras order by id ASC");
	$cont = mysql_num_rows($sql);
	while($exibir = mysql_fetch_array($sql)){
	
      echo $exibir['1']."-  -  -  -";
	  echo "<a href=\"?acao=excluir&id=".$exibir['0']."\">Excluir</a><br /><br />";
      }
      
      ?></td>
      <td width="106" bgcolor="#EBF0FA"><label></label></td>
    </tr>
  </table>
  <p>
    <label></label>
  </p>
  <p><a href="javascript:window.history.back(-1)">Voltar</a>&nbsp;</p>
  <p>&nbsp;</p>
  <p></p>
  <p>&nbsp;</p>
</div>
</body>
</html>

<?php 
		
		if($_GET['acao'] == "excluir"){
		$id = $_GET['id'];
		
		mysql_query("delete from regras where id='$id' limit 1");

		echo "<script>alert(\"Regra excluida com sucesso!\")</script>";
		echo "<script>window.history.back(-1)</script>";
		}	


?>
