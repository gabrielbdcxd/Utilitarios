<?php 
include "../config.php";
include "data.php";
session_start();
			if(!isset($_SESSION['usuadminro']) && !isset($_SESSION['senhaadminro'])){
				echo "<script>alert(\"Acesso Negado!\")</script>";
				exit;
			}
			
			
	    mysql_connect($CONFIG['server'], $CONFIG['user'], $CONFIG['senha']);
	    mysql_select_db($CONFIG['dbsite']);
		
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"/>
<title><?php echo $CONFIG['titulo']; ?></title>
<link href="../estilos/style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">
<!--
function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}
//-->
</script>
<style type="text/css">
<!--
body {
	background-color: #F3F3F3;
}
-->
</style></head>
<body>
<div align="center" class="textos">
  <form name="dsad" method="post" action="">
  <table width="583" border="0" align="center" cellpadding="4" cellspacing="2">
    <tr>
      <td colspan="2"><div align="center" class="titulostabela">
        <p>Nova Not&iacute;cia</p>
      </div></td>
    </tr>
    
    <tr>
      <td bgcolor="#EBF0FA">Titulo:</td>
      <td bgcolor="#EBF0FA"><input name="titulo" type="text" class="filds" id="titulo" size="70," /></td>
    </tr>
    <tr>
      <td bgcolor="#EBF0FA"><div align="right">Not&iacute;cia:</div></td>
      <td bgcolor="#EBF0FA"><label>
        <textarea name="noticia" cols="60" rows="5" id="noticia"></textarea>
      </label></td>
    </tr>
    <tr>
      <td bgcolor="#EBF0FA"><div align="right">Data:</div></td>
      <td bgcolor="#EBF0FA"><label>
        <input name="data" type="text" class="filds" id="data" value="<?php echo $dia; ?>/<?php echo $mes; ?>/<?php echo $ano; ?>" />
      </label></td>
    </tr>
    <tr>
      <td width="41" bgcolor="#EBF0FA"><div align="right">Por:</div></td>
      <td width="528" bgcolor="#EBF0FA"><label>
        <input name="por" type="text" class="filds" id="por" />
      </label></td>
    </tr>
      
      
      
    <tr>
      <td bgcolor="#EBF0FA"><div align="right"></div></td>
      <td width="528" bgcolor="#EBF0FA"><label>
        <input name="enviar" type="submit" class="filds" id="enviar" value="Enviar" />
      </label></td>
    </tr>
  </table>
  </form>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p></p>
  <p>&nbsp;</p>
</div>
</body>
</html>

<?php 
		$enviar = $_POST['enviar'];
		
		if(isset($enviar)){
		$titulo = $_POST['titulo'];
		$noticia = $_POST['noticia'];
		$data = $_POST['data'];
		$por = $_POST['por'];
		
		$inserir = mysql_query("INSERT INTO noticias (titulo, noticia, data, por)values ('$titulo', '$noticia', '$data', '$por')");
		if($inserir != null){
		echo "<script>alert(\"Not�cia enviada com sucesso!\")</script>";
		}else{
		echo "<script>alert(\"Erro: Ocorreu um erro!\")</script>";
		
		}
		}



?>
