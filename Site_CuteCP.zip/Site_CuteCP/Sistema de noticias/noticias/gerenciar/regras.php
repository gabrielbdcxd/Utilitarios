<?php 
include "../config.php";
include "data.php";
session_start();
			if(!isset($_SESSION['usuadminro']) && !isset($_SESSION['senhaadminro'])){
				echo "<script>alert(\"Acesso Negado!\")</script>";
				exit;
			}
			
			
	    mysql_connect($CONFIG['server'], $CONFIG['user'], $CONFIG['senha']);
	    mysql_select_db($CONFIG['dbsite']);
		$sql = mysql_query("SELECT * FROM ".$CONFIG['dbsite'].".regras order by id ASC");
	$cont = mysql_num_rows($sql);
	$exibir = mysql_fetch_array($sql);
		
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"/>
<title><?php echo $CONFIG['titulo']; ?></title>
<link href="../estilos/style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">
<!--
function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}
//-->
</script>
<style type="text/css">
<!--
body {
	background-color: #F3F3F3;
}
-->
</style></head>
<body>
<div align="center" class="textos">
  <form name="dsad" method="post" action="">
  <table width="583" border="0" align="center" cellpadding="4" cellspacing="2">
    <tr>
      <td colspan="2"><div align="center" class="titulostabela">
        <p>Inserir regras  <?php echo $CONFIG['nome']; ?></p>
      </div></td>
    </tr>
    
    <tr>
      <td width="116" bgcolor="#EBF0FA"><div align="right">Novas regras: :</div></td>
      <td width="445" bgcolor="#EBF0FA"><label>
        <input name="reg" type="text" id="reg" size="70" />
        <br />
        <br />
        <input name="reg2" type="text" id="reg2" size="70" />
        <br />
        <br />
        <input name="reg3" type="text" id="reg3" size="70" />
        <br />
        <br />
        <input name="reg4" type="text" id="reg4" size="70" />
        <br />
        <br />
        <input name="reg5" type="text" id="reg5" size="70" />
        <br />
        <br />
      </label></td>
    </tr>
  </table>
  <p>
    <label>
    <input name="enviar" type="submit" class="filds" id="enviar" value="Enviar" />
    </label>
    </p>
  <p><a href="javascript:window.history.back(-1)">Voltar</a>&nbsp;</p>
  <p> _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _<br />
  </p>
  <p><a href="excluir_reg.php">Excluir regras existentes!<br />
  </a>_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _</p>
  </form>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p></p>
  <p>&nbsp;</p>
</div>
</body>
</html>

<?php 
		$enviar = $_POST['enviar'];
		
		if(isset($enviar)){
		$reg = $_POST['reg'];
		$reg2 = $_POST['reg2'];
		$reg3 = $_POST['reg3'];
		$reg4 = $_POST['reg4'];
		$reg5 = $_POST['reg5'];
		
		
		mysql_query("insert into regras (regra) values ('$reg')");
		mysql_query("insert into regras (regra) values ('$reg2')");
		mysql_query("insert into regras (regra) values ('$reg3')");
		mysql_query("insert into regras (regra) values ('$reg4')");
		mysql_query("insert into regras (regra) values ('$reg5')");

		echo "<script>alert(\"Regra(s) enviada(s) com sucesso!\")</script>";
		}


?>
