<?php 
include "../config.php";
include "../antisql.php";
$entrar = $_POST['entrar'];
		if(isset($entrar)){
		$usu = anti_injection($_POST['usuro']);
		$senha = anti_injection($_POST['senharo']);
		
		mysql_connect($CONFIG['server'], $CONFIG['user'], $CONFIG['senha']);
	    mysql_select_db($CONFIG['dbsite']);
		
		$confere = mysql_query("SELECT usuario AND senha from ".$CONFIG['dbsite'].".admin where usuario='$usu' AND senha='$senha'");
		$cont = mysql_num_rows($confere);
		
		if($cont == 0){
		echo "<script>alert(\"Usu�rio e/ou senha errados!\")</script>";
		}
		if($cont == 1){
		
		session_start();
		$_SESSION['usuadminro'] = $usu;
		$_SESSION['senhaadminro'] = $senha;
		header("Location: inicial.php");
		
		
		}
		
		}


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"/>
<title><?php echo $CONFIG['titulo']; ?></title>
<link href="../estilos/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<form name="loginadm" action="" method="post">
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p align="center" class="textos"><strong><?php echo $CONFIG['nome']; ?></strong><br />
 <span class="textos"> Administra&ccedil;&atilde;o do site</span></p>
<table width="246" border="0" align="center" cellpadding="5" cellspacing="0">
  <tr>
    <td colspan="2"><div align="center"><img src="../images/login.gif" width="428" height="49" /></div></td>
  </tr>
  <tr>
    <td width="79" bgcolor="#ECF9FF"><div align="right" class="textos">Usu&aacute;rio:</div></td>
    <td width="349" bgcolor="#ECF9FF"><label>
      <input name="usuro" type="text" class="filds" id="usuro" />
      <img src="../images/usua.gif" width="16" height="16" /></label></td>
  </tr>
  <tr>
    <td bgcolor="#B1D8ED"><div align="right"  class="textos">Senha:</div></td>
    <td bgcolor="#B1D8ED"><label>
      <input name="senharo" type="password" class="filds" id="senharo" />
      <img src="../images/senha.gif" width="16" height="16" /></label></td>
  </tr>
  <tr>
    <td bgcolor="#ECF9FF">&nbsp;</td>
    <td bgcolor="#ECF9FF"><label>
      <input type="submit" name="entrar" id="entrar" class="filds" value="Entrar" />
    </label></td>
  </tr>
</table>
<p>&nbsp;</p>

</form>
</body>
</html>