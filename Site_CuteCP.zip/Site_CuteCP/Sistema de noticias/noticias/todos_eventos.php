<script>
function abrir(pagina,largura,altura) {

//pega a resolu��o do visitante
w = screen.width;
h = screen.height;

//divide a resolu��o por 2, obtendo o centro do monitor
meio_w = w/2;
meio_h = h/2;

//diminui o valor da metade da resolu��o pelo tamanho da janela, fazendo com q ela fique centralizada
altura2 = altura/2;
largura2 = largura/2;
meio1 = meio_h-altura2;
meio2 = meio_w-largura2;

//abre a nova janela, j� com a sua devida posi��o
window.open(pagina,'','height=' + altura + ', width=' + largura + ', top='+meio1+', left='+meio2+'');
}
</script>
<link href="estilos/style.css" rel="stylesheet" type="text/css" />
<div align="left">
  <style type="text/css">
<!--
body {
	background-color: #F3F8FE;
}
-->
    </style>
</div>
<?php
include "config.php";
$noticia = mysql_query("SELECT * FROM ".$CONFIG['dbsite'].".eventos order by id desc");

 while ($exibir2 = mysql_fetch_array($noticia)){
      echo "<table width=\"428\" border=\"0\" cellspacing=\"1\" cellpadding=\"3\" align=\"center\"\">
        <tr>
          <td width=\"18%\" bgcolor=\"#B4D6EF\"><div align=\"center\" class=\"data\">".$exibir2[3]."</div></td>
          <td width=\"82%\" bgcolor=\"#C7E0F3\"> <span class=\"titulonoti\"><a href=\"javascript:abrir('evento.php?id=".$exibir2[0]."','600','400');\">".$exibir2[1]."</a></span></td>
        </tr>
      </table>";
    }

?>