<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>::The Rag::</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
Downloads do servidor
<ul><br />
<span style="text-align:left; list-style:none;">
  <font face="Arial, Helvetica, sans-serif" size="3" color="#FF9900">  <li>Como instalar</li>
  <br />
  </font>
  <li><font color="#666" size="1" face="Arial, Helvetica, sans-serif">Ap&oacute;s baixar e instalar o servidor, voc&ecirc; deve c&oacute;piar o arquivo&nbsp;<strong>data.gr</strong></font><br />
  <font color="#666" size="1" face="Arial, Helvetica, sans-serif">da pasta do seu Ragnar&ouml;k Online que se encontra no disco local C para</font><br />
  <font color="#666" size="1" face="Arial, Helvetica, sans-serif">a pasta aonde est&aacute; instalado o&nbsp;<strong>The Rag</strong>. Ap&oacute;s isso, basta executar o</font><br />
  <font color="#666" size="1" face="Arial, Helvetica, sans-serif">arquivo exe dentro da pasta instalada.</font>
  <li><br />
    <font face="Arial, Helvetica, sans-serif" size="3" color="#FF9900">
    </font><font face="Arial, Helvetica, sans-serif" size="3" color="#FF9900"></font><font face="Arial, Helvetica, sans-serif" size="3" color="#FF9900"></font><font face="Arial, Helvetica, sans-serif" size="3" color="#FF9900"></font>  
  <font face="Arial, Helvetica, sans-serif" size="3" color="#FF9900">
  <li>Download do patch the-rag</li><br />
  </font>
  <font face="Arial, Helvetica, sans-serif" size="1" color="#666">
  <li>Nome do Arquivo: Install_the-rag.exe</li>
  <li>Tamanho: 30mb</li>
  <li>Downloads: <a href="#">LINK</a></li>
  </font>
  <br />
  <font face="Arial, Helvetica, sans-serif" size="3" color="#FF9900">
    <li>Download do BRO</li><br />
  </font>
  <font face="Arial, Helvetica, sans-serif" size="1" color="#666">
  <li>Nome do Arquivo: Cliente BRO</li>
  <li>Tamanho: 1,5gb</li>
  <li>Downloads: <a href="http://levelupgames.uol.com.br/ragnarok/downloads/comece-jogar/instrucoes.lhtml">LINK</a></li>
  
  </font>
</ul>
</body>
</html>