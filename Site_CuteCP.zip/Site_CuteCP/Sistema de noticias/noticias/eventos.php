  <STYLE>
    BODY
    {
      cursor: url("ragarrow.cur");
      scrollbar-arrow-color: #C0C0C0;
      scrollbar-track-color: #FFFFFF;
      scrollbar-face-color: #FFFFFF;
      scrollbar-highlight-color: #C0C0C0;
      scrollbar-3dlight-color: #FFFFFF;
      scrollbar-darkshadow-color: #FFFFFF;
      scrollbar-shadow-color: #C0C0C0;
      background-color: #FFFFFF;
    }
  </STYLE>
<?php 
include "config.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"/>
<title>news</title>
<link href="estilos/style.css" rel="stylesheet" type="text/css" />
<script>
function abrir(pagina,largura,altura) {

//pega a resolu��o do visitante
w = screen.width;
h = screen.height;

//divide a resolu��o por 2, obtendo o centro do monitor
meio_w = w/2;
meio_h = h/2;

//diminui o valor da metade da resolu��o pelo tamanho da janela, fazendo com q ela fique centralizada
altura2 = altura/2;
largura2 = largura/2;
meio1 = meio_h-altura2;
meio2 = meio_w-largura2;

//abre a nova janela, j� com a sua devida posi��o
window.open(pagina,'','height=' + altura + ', width=' + largura + ', top='+meio1+', left='+meio2+'');
}
</script>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<style type="text/css">

body {
	background: url('images/bg.jpg') no-repeat center top;
	background-repeat: repeat;
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	text-align: center;
	color: #97BDFE;
	background-image: url();
	background-color: #FFFFFF;
}
</style>
</head>
</head>
<body>
<div align="left"><span style="height:105px; font-size:11pt; color:#727272; font-weight:normal; line-height:160%; padding-top:8px">
  <?php 
	  		if(isset($_GET['pag'])){
			$pag = $_GET['pag'];				
				if(file_exists("$pag.php")){
				include "$pag.php";
				}else{ include "404.php"; }
			
			}else{ include "home2.php"; }	  
	  ?>
</span></div>
</body>
</html>
