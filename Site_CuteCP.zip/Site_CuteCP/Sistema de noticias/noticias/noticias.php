<?php 
include "config.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"/>
<title>news</title>
<script>
function abrir(pagina,largura,altura) {

//pega a resolu��o do visitante
w = screen.width;
h = screen.height;

//divide a resolu��o por 2, obtendo o centro do monitor
meio_w = w/2;
meio_h = h/2;

//diminui o valor da metade da resolu��o pelo tamanho da janela, fazendo com q ela fique centralizada
altura2 = altura/2;
largura2 = largura/2;
meio1 = meio_h-altura2;
meio2 = meio_w-largura2;

//abre a nova janela, j� com a sua devida posi��o
window.open(pagina,'','height=' + altura + ', width=' + largura + ', top='+meio1+', left='+meio2+'');
}
</script>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<style type="text/css">
.oculta{
display: none;
}
.filds {
	font-size: 13px;
	font-family: Arial, Helvetica, sans-serif;
	color: #316A0F;
	border: 1px dashed #6CB6FF;
}
.hallfama {
font-size: 11px; font-family: Arial, Helvetica, sans-serif; color: #003333; 
}
.textos {
	font-size: 15px;
	font-family: Arial, Helvetica, sans-serif;
	color: #09F;
	clip: rect(auto,5px,auto,auto);
}
.bordastabelas {
	font-size: 15px;
	border: medium solid #267AB0;
}
.data {
	color: #003366;
	font-size: 15px;
	font-family: Arial, Helvetica, sans-serif;

}
.creditos {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 15px;
	color: #F0F0F0;
}
.titulostabela {
	font-size: 17px;
	font-family: Verdana, Arial, "Times New Roman", Times, serif;
	color: #009966;
	border: thin solid #CAEEFF;
}
a:link {
	color: #006666;
	text-decoration: none;
}
a:visited {
	text-decoration: none;
	color: #006666;
}
a:hover {
	text-decoration: none;
	color: #FF0000;
}
a:active {
	text-decoration: none;
	color: #FFFFFF;
	background-color: #000000;
}
a {
	font-family: Arial, Helvetica, sans-serif;
}.creditos {
	text-align: center;


}


</style>
</head>
</head>
<body>
<div align="left"><span style="height:105px; font-size:11pt; color:#727272; font-weight:normal; line-height:160%; padding-top:8px">
  <?php 
	  		if(isset($_GET['pag'])){
			$pag = $_GET['pag'];				
				if(file_exists("$pag.php")){
				include "$pag.php";
				}else{ include "404.php"; }
			
			}else{ include "homee.php"; }	  
	  ?>
</span></div>
</body>

