<?php 

// CONFIGURA��ES DA DATABASE
$CONFIG['server'] = "localhost";   // servidor do banco de dados
$CONFIG['user'] = "pizcphic_futura";          // Usuario do banco de dados 
$CONFIG['senha'] = "futura";    // Senha do banco de dados
$CONFIG['dbsite'] = "pizcphic_futura";      // N�o mude ou o site n�o funcionara



// CONFIGURA��ES DO SITE
$CONFIG['titulo'] = "Sistema de Noticias";     // Titulo do site
$CONFIG['imgtopo'] = "1"; //Habilitar imagem em baixo do menu? (sim:1 n�o:0) 
$CONFIG['linkforum'] = "the-rag.net/forum";     /* Link para o f�rum (caso o link n�o seja "seusite.com/forum coloque um http:// por exemplo: http://forum.com.br) */
$CONFIG['linkorkut'] = "http://orkut";   // Link pra comuniadade do orkut
$CONFIG['linktop'] = "http://top";   // Link pro top BR
$CONFIG['linkvip'] = "/forum/vip";   // Link para explica��o VIP no f�rum
$CONFIG['mincaracteres'] = 4;     // M�nimo de caracteres para registro(login, senha)
$CONFIG['maxcaracteres'] = 24;  // M�ximo de caracteres para registro(login, senha)
$CONFIG['diawoe1'] = "Segunda - De 13:00 as 15:00"; // dia 1 e hora da woe 
$CONFIG['diawoe2'] = "Ter�a - De 13:00 as 15:00"; // dia 2 e hora da woe
$CONFIG['diawoe3'] = ""; // dia 4 e hora da woe (deixe vazio caso n�o tenha)


// INFORMA��ES DO SERVIDOR (p�gina informa��es)
$CONFIG['nome'] = "THE RAG";         // Nome do seu servidor
$CONFIG['servidor'] = "THE RAG";         // Nome do seu servidor
$CONFIG['rates'] = "100k/100k/100%";         // Rates do seu servidor
$CONFIG['lvl'] = "999/255";         // Level m�ximo do seu servidor
$CONFIG['atributo'] = "600";         // Atributos m�ximos do seu servidor
$CONFIG['atributobb'] = "600";         // Atributos m�ximos para baby do seu servidor
$CONFIG['comandoslib'] = "@go - Libera teleporte para cidades<br>@die - Mata seu personagem ";/* Comandos liberados (use <br> para pula uma linha depois de cada descri��o de comando.)*/
$CONFIG['npcslib'] = "Teleportadora<br>Vendedor<br>Super Kafra<br> Npc Custom<br> Npc Evento<br>"; // NPCs liberados (coloque <br> depois de cada npc)
$CONFIG['palavras'] = ""; // palavras para ficar na pagina informa��es.



mysql_connect($CONFIG['server'], $CONFIG['user'], $CONFIG['senha']);

?>