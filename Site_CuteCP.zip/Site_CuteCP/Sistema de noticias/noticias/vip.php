<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>::The Rag::</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
Doa&ccedil;&otilde;es do servidor
<ul><br />
<span style="text-align:left; list-style:none;">
  <font face="Arial, Helvetica, sans-serif" size="3" color="#FF9900">  <li>Porque doar?</li>
  <br />
  </font>
  <li><font color="#666" size="1" face="Arial, Helvetica, sans-serif">Como voc� j� deve saber, o <strong>The Rag</strong> � um servidor totalmente gr�tis e sem fins lucrativos. N�s contamos puramente com as doa��es dos jogadores para continuar mantendo o servidor aberto, gr�tis e sem limite de jogadores online ao mesmo tempo. Com o dinheiro arrecadado atrav�s de doa��es utilizamos para bancar as dispesas como: servidor dedicado, hospedagens, sistema de seguran�a, entre outras coisas.</font>
  <li><br />
    <font face="Arial, Helvetica, sans-serif" size="3" color="#FF9900">
    </font><font face="Arial, Helvetica, sans-serif" size="3" color="#FF9900"></font><font face="Arial, Helvetica, sans-serif" size="3" color="#FF9900"></font><font face="Arial, Helvetica, sans-serif" size="3" color="#FF9900"></font>  
  <font face="Arial, Helvetica, sans-serif" size="3" color="#FF9900">
  <li>Como doar?</li>
  <br />
  </font>
  
  <li><font color="#666" size="1" face="Arial, Helvetica, sans-serif">Para&nbsp;<strong>fazer</strong>&nbsp;sua doa&ccedil;&atilde;o,&nbsp;<a href="#" target="_blank">Clique aqui</a>.
    </font><div></div>
    <font color="#666" size="1" face="Arial, Helvetica, sans-serif">
    Confirma&ccedil;&atilde;o de doa&ccedil;&otilde;es via PagSeguro s&atilde;o feitas automaticamente, Via Deposito basta confirma ap&oacute;s a doa&ccedil;&atilde;o, na <a href="#">Clique aqui</a></font></li>
  <li><font color="#666" size="1" face="Arial, Helvetica, sans-serif"><br />
    
  </font></li>
  <font face="Arial, Helvetica, sans-serif" size="3" color="#FF9900">
  <li>Vantagens de doar</li>
  <br />
  </font>
  
  <li><font color="#666" size="1" face="Arial, Helvetica, sans-serif">H&aacute; inumeras vantagens para os jogadores que ajudam o servidor, al&eacute;m dos rops, ele pode adquirir cart&otilde;es VIP, e equipamentos exclusivos.</font></li>
</ul>
</body>
</html>