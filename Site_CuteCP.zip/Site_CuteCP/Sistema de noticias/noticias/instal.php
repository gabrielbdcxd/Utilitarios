<div align="center"><a href="?acao=instal">Clique aqui.</a></div>
<p>
  <?php 

if($_GET['acao'] == "instal"){
include_once 'config.php';
	mysql_connect($CONFIG['server'], $CONFIG['user'], $CONFIG['senha']) or die ("Configure o arquivo config.php");
	mysql_query("CREATE DATABASE `arquivos_sys`");
	
	mysql_query("CREATE TABLE `njordbrn_sys`.`fama` (
`id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`foto` VARCHAR( 100 ) NOT NULL ,
`nome` VARCHAR( 100 ) NOT NULL ,
`nick` VARCHAR( 100 ) NOT NULL ,
`classe` VARCHAR( 100 ) NOT NULL ,
`cla` VARCHAR( 100 ) NOT NULL ,
`idade` VARCHAR( 100 ) NOT NULL ,
`mora` VARCHAR( 100 ) NOT NULL
) ENGINE = MYISAM");

	mysql_query("CREATE TABLE `njordbrn_sys`.`regras` (
`id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`regra` TEXT NOT NULL
) ENGINE = MYISAM");

	mysql_query("CREATE TABLE `njordbrn_sys`.`download` (
`id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`versao_pat` VARCHAR( 50 ) NOT NULL ,
`tamanho_pat` VARCHAR( 50 ) NOT NULL ,
`link_pat` TEXT NOT NULL ,
`episodio_bro` VARCHAR( 50 ) NOT NULL ,
`tamanho_bro` VARCHAR( 50 ) NOT NULL ,
`link_bro` TEXT NOT NULL
) ENGINE = MYISAM");

	mysql_query("CREATE TABLE `njordbrn_sys`.`equipe` (
`id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`cargo` VARCHAR( 50 ) NOT NULL ,
`nome` VARCHAR( 50 ) NOT NULL ,
`especi` TEXT NOT NULL
) ENGINE = MYISAM");

	mysql_query("CREATE TABLE `njordbrn_sys`.`noticias` (
`id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`titulo` TEXT NOT NULL ,
`noticia` TEXT NOT NULL ,
`data` VARCHAR( 20 ) NOT NULL ,
`por` VARCHAR( 50 ) NOT NULL
) ENGINE = MYISAM");


	mysql_query("CREATE TABLE `njordbrn_sys`.`eventos` (
`id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`titulo` TEXT NOT NULL ,
`evento` TEXT NOT NULL ,
`data` VARCHAR( 20 ) NOT NULL
) ENGINE = MYISAM");

	mysql_query("CREATE TABLE `njordbrn_sys`.`admin` (
`id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`usuario` VARCHAR( 50 ) NOT NULL ,
`senha` VARCHAR( 50 ) NOT NULL ,
`privilegio` VARCHAR( 2 ) NOT NULL
) ENGINE = MYISAM");




		}
		
		if($_GET['acao'] == "instal"){
		echo "Pronto agora crie um usu�rio para administra�o abaixo...";
		
		
		
				
?>
</p>
<form id="form1" name="form1" method="post" action="">

<p>Usuario:</p>
  <label>
  <input type="text" name="usu" id="usu" />
  </label>
  <p>Senha:</p>
  <p>
    <input type="password" name="senha1" id="senha1" />
  </p>
  <p>Repita a senha:</p>
  <p>
    <input type="password" name="senha2" id="senha2" />
  </p>
  <p>
    <label>
    <input type="submit" name="enviar" id="button" value="Enviar" />
    </label>
  </p>
</form>
<p>&nbsp; </p>
<?php } ?>


<?php

		if(isset($_POST['enviar'])){
		
		 if($_POST['senha1'] == $_POST['senha2']){
		 $usuario = $_POST['usu'];
		 $senha = $_POST['senha1'];
		
		mysql_query("INSERT INTO ".$CONFIG['dbsite'].".admin (usuario, senha) values ('$usuario', '$senha')");
		
		
}else{echo "As senhas est� diferentes... tente denovo";}

}
