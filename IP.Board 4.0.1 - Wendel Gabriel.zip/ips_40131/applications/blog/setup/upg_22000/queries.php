<?php

$SQL[] = "DELETE FROM core_sys_conf_settings WHERE conf_key IN('blog_use_friendlyurls', 'blog_friendly_url', 'blog_friendlyurl_path', 'blog_boardindex_path');";
