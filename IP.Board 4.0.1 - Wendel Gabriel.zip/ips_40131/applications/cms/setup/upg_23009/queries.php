<?php

$SQL[] = "ALTER TABLE ccs_database_fields ADD COLUMN field_filter TINYINT(1) NOT NULL DEFAULT 0;";

//