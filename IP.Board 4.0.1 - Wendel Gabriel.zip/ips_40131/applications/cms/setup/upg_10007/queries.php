<?php

$SQL[]	= "ALTER TABLE ccs_block_wizard CHANGE wizard_name wizard_name VARCHAR( 255 ) NULL DEFAULT NULL;";
