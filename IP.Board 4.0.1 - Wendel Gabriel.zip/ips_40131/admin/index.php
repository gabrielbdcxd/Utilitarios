<?php
/**
 * @brief		Admin CP bootstrap
 *
 * @copyright	(c) 2001 - SVN_YYYY Invision Power Services, Inc.
 *
 * @package		IPS Social Suite
 * @since		18 Feb 2013
 * @version		SVN_VERSION_NUMBER
 */

require_once '../init.php';
\IPS\Dispatcher\Admin::i()->run();